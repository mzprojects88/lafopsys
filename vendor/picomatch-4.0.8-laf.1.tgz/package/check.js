'use strict';

// Self-check for the LAF build of picomatch: the official 4.0.7 plus the fix for
// GHSA-fc5q-39xc-vjpf. Run `node check.js`. It prints "ok" or stops with an error.

const assert = require('assert');
const pm = require('./');
const { escapeRegex } = require('./lib/utils');

const hostile = ['a'.repeat(60) + '!', 'a'.repeat(60) + '/', 'ab'.repeat(30) + '!'];

// A repeated extglob with a branch of variable width is matched as plain text.
// The compiled regex is checked first: it must be the pattern's own spelling.
// Only then are the hostile strings tried, so this check cannot hang (an
// unpatched build fails on the first line of the loop instead).
const refused = [
  ['+(*)'],
  ['+(*a)'],
  ['*(*a)'],
  ['+(a*)'],
  ['+(a*b)'],
  ['+(a+)'],
  ['+([a-z]+)'],
  ['+(a*(a))'],
  ['+(a+(a))'],
  ['+(a?(a))'],
  ['+(@(a|aa))'],
  ['+({a,aa})'],
  ['+(!(a))'],
  ['+((a|aa))'],
  ['+(*a|b)'],
  ['+(b|a+)'],
  ['*("a"?a)'],
  ['*(aa|ab|"a")b'],
  ['+(a\\\\\\\\?a)'],
  ['+(a{1,9})', { nobrace: true }],
  ['+(a\\*)', { unescape: true }],
  ['+(aa\\?a)', { unescape: true }],
  ['+( \\*)', { unescape: true }]
];

for (const [pattern, options] of refused) {
  assert.strictEqual(pm.makeRe(pattern, options).source, `^(?:${escapeRegex(pattern)})$`, `${pattern} must compile to plain text`);

  for (const input of hostile) {
    assert.strictEqual(pm.isMatch(input, pattern, options), false, `${pattern} must not match ${input.slice(0, 6)}...`);
  }
}

assert.strictEqual(pm.isMatch('+(*a)', '+(*a)'), true, 'the plain-text form matches its own spelling');

// Everything else compiles as it does in 4.0.7.
const kept = [
  ['123', '+([0-9])', true],
  ['12a', '+([0-9])', false],
  ['abba', '+(a|b)', true],
  ['abc', '+(a|b)', false],
  ['abab', '+(ab)', true],
  ['aba', '+(ab)', false],
  ['axay', '+(a?)', true],
  ['a.b', '+(a|\\.|b)', true],
  ['a.jsx', '*.+(js|jsx)', true],
  ['a.ts', '*.+(js|jsx)', false],
  ['azzz', 'a+(z)', true],
  ['a', 'a+(z)', false],
  ['azzz', 'a*(z)', true],
  ['abac', '*(a|b)c', true],
  ['button.test.tsx', '?(*.)+(spec|test).[jt]s?(x)', true],
  ['xa', '@(*a|*b)', true],
  ['ab', '?(a*)b', true],
  ['x.ts', '!(*.d).ts', true],
  ['x.d.ts', '!(*.d).ts', false],
  ['foo.bar', '!(!(foo)).!(!(bar))', true]
];

for (const [input, pattern, expected] of kept) {
  assert.strictEqual(pm.isMatch(input, pattern), expected, `${pattern} on ${input}`);
}

// The documented switches still work: a nested repeat on request, and the safeguard off.
assert.strictEqual(pm.isMatch('aaa', '+(+(a))', { maxExtglobRecursion: 1 }), true);
assert.strictEqual(pm.isMatch('xaya', '+(*a)', { maxExtglobRecursion: false }), true);
assert.strictEqual(pm.makeRe('+(a|aa)').source, '^(?:\\+\\(a\\|aa\\))$');

console.log(`ok: ${refused.length} risky forms refused, ${kept.length} ordinary forms unchanged`);
